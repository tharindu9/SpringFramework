package com.tharindu.employeeservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.tharindu.employeeservice.modal.Employee;
import com.tharindu.employeeservice.modal.Telephone;
import com.tharindu.employeeservice.repository.EmployeeRepository;

@Service
public class EmployeeServiceImp implements EmployeeService {
	
	@Autowired
	EmployeeRepository employeeService;
	 @Override
	public Employee save(Employee employee) {
		
	 for (Telephone telephone : employee.getTelephone()) {
		 telephone.setEmployee(employee);
		
	}
		
		return employeeService.save(employee);
	}
	 
	public List<Employee> fetchAllEmployee(){
		return employeeService.findAll();
	}


	

}
